# Dental CRM System - Startup Script for PowerShell

Write-Host ""
Write-Host "========================================"
Write-Host "Dental CRM System - Startup Script"
Write-Host "========================================"
Write-Host ""

Write-Host "Installing dependencies..." -ForegroundColor Cyan
npm install

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "ERROR: npm install failed" -ForegroundColor Red
    Write-Host "Make sure Node.js is installed: https://nodejs.org/" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "Starting server..." -ForegroundColor Cyan
Write-Host ""
Write-Host "Server will be available at:" -ForegroundColor Green
Write-Host "- Website: http://localhost:3000/home" -ForegroundColor White
Write-Host "- CRM: http://localhost:3000/admin" -ForegroundColor White
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

npm start
