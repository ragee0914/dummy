@echo off
echo.
echo ========================================
echo Dental CRM System - Startup Script
echo ========================================
echo.

echo Installing dependencies...
call npm install

if errorlevel 1 (
    echo.
    echo ERROR: npm install failed
    echo Make sure Node.js is installed: https://nodejs.org/
    pause
    exit /b 1
)

echo.
echo Starting server...
echo.
echo Server will be available at:
echo - Website: http://localhost:3000/home
echo - CRM: http://localhost:3000/admin
echo.
echo Press Ctrl+C to stop the server
echo.

call npm start
