import { Patient, Appointment } from '../types';

export const mockPatients: Patient[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah.j@email.com',
    phone: '(555) 123-4567',
    dateOfBirth: '1985-06-15',
    lastVisit: '2026-02-15',
    nextAppointment: '2026-03-10',
    insuranceProvider: 'Delta Dental',
    status: 'active',
    notes: 'Regular patient, no allergies'
  },
  {
    id: '2',
    name: 'Michael Chen',
    email: 'mchen@email.com',
    phone: '(555) 234-5678',
    dateOfBirth: '1990-03-22',
    lastVisit: '2026-01-20',
    nextAppointment: '2026-03-08',
    insuranceProvider: 'Cigna',
    status: 'active',
    notes: 'Allergic to penicillin'
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily.r@email.com',
    phone: '(555) 345-6789',
    dateOfBirth: '1978-11-30',
    lastVisit: '2026-02-28',
    nextAppointment: '2026-03-12',
    insuranceProvider: 'Aetna',
    status: 'active'
  },
  {
    id: '4',
    name: 'David Thompson',
    email: 'dthompson@email.com',
    phone: '(555) 456-7890',
    dateOfBirth: '1995-08-14',
    lastVisit: '2025-12-10',
    insuranceProvider: 'United Healthcare',
    status: 'active'
  },
  {
    id: '5',
    name: 'Jessica Martinez',
    email: 'jmartinez@email.com',
    phone: '(555) 567-8901',
    dateOfBirth: '1988-04-25',
    lastVisit: '2026-02-22',
    nextAppointment: '2026-03-15',
    insuranceProvider: 'Delta Dental',
    status: 'active',
    notes: 'Prefers morning appointments'
  },
  {
    id: '6',
    name: 'Robert Williams',
    email: 'rwilliams@email.com',
    phone: '(555) 678-9012',
    dateOfBirth: '1982-09-18',
    lastVisit: '2026-01-15',
    nextAppointment: '2026-03-20',
    insuranceProvider: 'MetLife',
    status: 'active'
  },
  {
    id: '7',
    name: 'Amanda Brown',
    email: 'abrown@email.com',
    phone: '(555) 789-0123',
    dateOfBirth: '1992-12-05',
    lastVisit: '2025-11-30',
    status: 'active'
  },
  {
    id: '8',
    name: 'James Wilson',
    email: 'jwilson@email.com',
    phone: '(555) 890-1234',
    dateOfBirth: '1975-07-20',
    lastVisit: '2026-02-10',
    insuranceProvider: 'Cigna',
    status: 'inactive',
    notes: 'Moved to different city'
  }
];

export const mockAppointments: Appointment[] = [
  {
    id: 'a1',
    patientId: '1',
    patientName: 'Sarah Johnson',
    date: '2026-03-05',
    time: '09:00',
    type: 'Checkup',
    status: 'confirmed',
    dentist: 'Dr. Smith',
    notes: 'Regular 6-month checkup'
  },
  {
    id: 'a2',
    patientId: '2',
    patientName: 'Michael Chen',
    date: '2026-03-05',
    time: '10:30',
    type: 'Filling',
    status: 'confirmed',
    dentist: 'Dr. Johnson'
  },
  {
    id: 'a3',
    patientId: '3',
    patientName: 'Emily Rodriguez',
    date: '2026-03-05',
    time: '14:00',
    type: 'Cleaning',
    status: 'confirmed',
    dentist: 'Dr. Smith'
  },
  {
    id: 'a4',
    patientId: '5',
    patientName: 'Jessica Martinez',
    date: '2026-03-06',
    time: '09:30',
    type: 'Checkup',
    status: 'scheduled',
    dentist: 'Dr. Lee'
  },
  {
    id: 'a5',
    patientId: '2',
    patientName: 'Michael Chen',
    date: '2026-03-08',
    time: '11:00',
    type: 'Root Canal',
    status: 'scheduled',
    dentist: 'Dr. Johnson',
    notes: 'Follow-up from previous visit'
  },
  {
    id: 'a6',
    patientId: '1',
    patientName: 'Sarah Johnson',
    date: '2026-03-10',
    time: '10:00',
    type: 'Cleaning',
    status: 'scheduled',
    dentist: 'Dr. Smith'
  },
  {
    id: 'a7',
    patientId: '3',
    patientName: 'Emily Rodriguez',
    date: '2026-03-12',
    time: '15:00',
    type: 'Consultation',
    status: 'scheduled',
    dentist: 'Dr. Lee'
  },
  {
    id: 'a8',
    patientId: '5',
    patientName: 'Jessica Martinez',
    date: '2026-03-15',
    time: '09:00',
    type: 'Filling',
    status: 'scheduled',
    dentist: 'Dr. Smith'
  },
  {
    id: 'a9',
    patientId: '6',
    patientName: 'Robert Williams',
    date: '2026-03-20',
    time: '13:30',
    type: 'Checkup',
    status: 'scheduled',
    dentist: 'Dr. Johnson'
  }
];
