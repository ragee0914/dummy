import { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { TeamSection } from './components/TeamSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { PatientPortal } from './components/PatientPortal';
import { AppointmentBookingDialog } from './components/AppointmentBookingDialog';
import { mockPatients, mockAppointments } from './data/mockData';
import { Patient, Appointment } from './types';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [patients] = useState<Patient[]>(mockPatients);
  const [appointments, setAppointments] = useState<Appointment[]>(mockAppointments);
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'website' | 'patient'>('website');
  const [currentPatient] = useState<Patient>(patients[0]);

  const patientAppointments = appointments.filter((apt) => apt.patientId === currentPatient.id);

  const handleBookAppointment = (appointmentData: Partial<Appointment>) => {
    const newAppointment: Appointment = {
      id: `a${appointments.length + 1}`,
      ...appointmentData
    } as Appointment;
    setAppointments([...appointments, newAppointment]);
    toast.success('Appointment booked successfully! We will contact you shortly to confirm.');
  };

  const handleCancelAppointment = (id: string) => {
    setAppointments(
      appointments.map((apt) =>
        apt.id === id ? { ...apt, status: 'cancelled' as const } : apt
      )
    );
  };

  const openBookingDialog = () => {
    setBookingDialogOpen(true);
  };

  if (viewMode === 'patient') {
    return (
      <div className="min-h-screen">
        <Toaster />
        <PatientPortal
          patient={currentPatient}
          appointments={patientAppointments}
          onBookAppointment={handleBookAppointment}
          onCancelAppointment={handleCancelAppointment}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Toaster />
      <Header 
        onBookAppointment={openBookingDialog}
        onPatientLogin={() => setViewMode('patient')}
      />
      <HeroSection onBookAppointment={openBookingDialog} />
      <ServicesSection />
      <TeamSection />
      <ContactSection onBookAppointment={openBookingDialog} />
      <Footer />

      <AppointmentBookingDialog
        open={bookingDialogOpen}
        onOpenChange={setBookingDialogOpen}
        patient={currentPatient}
        onBook={handleBookAppointment}
      />
    </div>
  );
}
