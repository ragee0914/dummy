import { Button } from './ui/button';
import { Phone, Clock, Calendar } from 'lucide-react';

interface HeaderProps {
  onBookAppointment: () => void;
  onPatientLogin?: () => void;
}

export function Header({ onBookAppointment, onPatientLogin }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="bg-teal-700 text-white">
        <div className="container mx-auto px-6 py-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>(555) 123-4567</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>Mon-Fri: 8AM-6PM | Sat: 9AM-2PM</span>
              </div>
            </div>
            {onPatientLogin && (
              <button
                onClick={onPatientLogin}
                className="hover:text-teal-100 transition-colors"
              >
                Patient Login
              </button>
            )}
          </div>
        </div>
      </div>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-teal-600 rounded-lg flex items-center justify-center">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="w-6 h-6 text-white"
              >
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" />
                <path d="M12 6c-1.66 0-3 1.34-3 3h2c0-.55.45-1 1-1s1 .45 1 1c0 1-1.5 1-1.5 2.5h2c0-1.5 1.5-1.5 1.5-2.5 0-1.66-1.34-3-3-3z" />
                <circle cx="12" cy="16" r="1" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Smile Dental Care</h1>
              <p className="text-xs text-gray-600">Your Family Dentist</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-gray-700 hover:text-teal-600 transition-colors">
              Home
            </a>
            <a href="#services" className="text-gray-700 hover:text-teal-600 transition-colors">
              Services
            </a>
            <a href="#team" className="text-gray-700 hover:text-teal-600 transition-colors">
              Our Team
            </a>
            <a href="#contact" className="text-gray-700 hover:text-teal-600 transition-colors">
              Contact
            </a>
          </nav>
          <Button onClick={onBookAppointment} className="bg-teal-600 hover:bg-teal-700">
            <Calendar className="mr-2 h-4 w-4" />
            Book Appointment
          </Button>
        </div>
      </div>
    </header>
  );
}
