import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Calendar, Users, Clock, CheckCircle } from 'lucide-react';

interface DashboardStatsProps {
  todayAppointments: number;
  totalPatients: number;
  upcomingAppointments: number;
  completedToday: number;
}

export function DashboardStats({
  todayAppointments,
  totalPatients,
  upcomingAppointments,
  completedToday
}: DashboardStatsProps) {
  const stats = [
    {
      title: "Today's Appointments",
      value: todayAppointments,
      icon: Calendar,
      color: 'text-blue-600'
    },
    {
      title: 'Total Patients',
      value: totalPatients,
      icon: Users,
      color: 'text-green-600'
    },
    {
      title: 'Upcoming',
      value: upcomingAppointments,
      icon: Clock,
      color: 'text-orange-600'
    },
    {
      title: 'Completed Today',
      value: completedToday,
      icon: CheckCircle,
      color: 'text-purple-600'
    }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <Icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
