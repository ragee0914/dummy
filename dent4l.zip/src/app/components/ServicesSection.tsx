import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Sparkles, Shield, Baby, Zap, Smile, Stethoscope } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const services = [
  {
    icon: Sparkles,
    title: 'Teeth Cleaning',
    description: 'Professional cleaning and polishing to keep your teeth healthy and bright.',
    color: 'bg-blue-100 text-blue-600'
  },
  {
    icon: Shield,
    title: 'Preventive Care',
    description: 'Regular checkups and preventive treatments to maintain optimal oral health.',
    color: 'bg-green-100 text-green-600'
  },
  {
    icon: Smile,
    title: 'Cosmetic Dentistry',
    description: 'Teeth whitening, veneers, and smile makeovers for a confident smile.',
    color: 'bg-purple-100 text-purple-600'
  },
  {
    icon: Stethoscope,
    title: 'Root Canal Therapy',
    description: 'Expert endodontic treatment to save damaged or infected teeth.',
    color: 'bg-red-100 text-red-600'
  },
  {
    icon: Baby,
    title: 'Pediatric Dentistry',
    description: 'Gentle, specialized care for children in a fun and comfortable environment.',
    color: 'bg-yellow-100 text-yellow-600'
  },
  {
    icon: Zap,
    title: 'Emergency Care',
    description: 'Same-day appointments available for dental emergencies and urgent care.',
    color: 'bg-orange-100 text-orange-600'
  }
];

export function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-teal-600 font-semibold text-sm uppercase tracking-wider">
            Our Services
          </span>
          <h2 className="text-4xl font-bold text-gray-900 mt-2 mb-4">
            Comprehensive Dental Care
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            From routine cleanings to advanced procedures, we offer complete dental services 
            for patients of all ages.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <Card key={service.title} className="border-2 hover:border-teal-200 hover:shadow-lg transition-all">
                <CardHeader>
                  <div className={`w-14 h-14 ${service.color} rounded-xl flex items-center justify-center mb-4`}>
                    <Icon className="h-7 w-7" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center bg-gradient-to-br from-teal-50 to-blue-50 rounded-3xl p-12">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              State-of-the-Art Technology
            </h3>
            <p className="text-lg text-gray-700 mb-6">
              We invest in the latest dental technology to provide you with the most comfortable, 
              efficient, and effective treatment possible. Our modern equipment ensures precise 
              diagnoses and superior results.
            </p>
            <ul className="space-y-4">
              {[
                'Digital X-Rays with reduced radiation',
                'Intraoral cameras for detailed imaging',
                'Laser dentistry for precise treatments',
                'CAD/CAM technology for same-day restorations'
              ].map((feature) => (
                <li key={feature} className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-teal-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1770321119305-f191c09c5801?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWNobm9sb2d5JTIwZXF1aXBtZW50fGVufDF8fHx8MTc3MjYwNDg1N3ww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Dental technology equipment"
              className="w-full h-[400px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
