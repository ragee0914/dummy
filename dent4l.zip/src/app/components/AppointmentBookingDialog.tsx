import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Patient, Appointment } from '../types';
import { useState } from 'react';
import { format } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';
import { cn } from './ui/utils';

interface AppointmentBookingDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patient: Patient;
  onBook: (appointment: Partial<Appointment>) => void;
}

const availableTimes = [
  '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'
];

const dentistOptions = [
  { value: 'Dr. Smith', specialty: 'General Dentistry' },
  { value: 'Dr. Johnson', specialty: 'Orthodontics' },
  { value: 'Dr. Lee', specialty: 'Endodontics' },
  { value: 'Dr. Martinez', specialty: 'Periodontics' }
];

export function AppointmentBookingDialog({
  open,
  onOpenChange,
  patient,
  onBook
}: AppointmentBookingDialogProps) {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState('');
  const [appointmentType, setAppointmentType] = useState<string>('Checkup');
  const [selectedDentist, setSelectedDentist] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDate || !selectedTime || !selectedDentist) {
      return;
    }

    const appointment: Partial<Appointment> = {
      patientId: patient.id,
      patientName: patient.name,
      date: format(selectedDate, 'yyyy-MM-dd'),
      time: selectedTime,
      type: appointmentType as any,
      status: 'scheduled',
      dentist: selectedDentist,
      notes: notes || undefined
    };

    onBook(appointment);
    
    // Reset form
    setSelectedDate(undefined);
    setSelectedTime('');
    setAppointmentType('Checkup');
    setSelectedDentist('');
    setNotes('');
    
    onOpenChange(false);
  };

  const handleCancel = () => {
    setSelectedDate(undefined);
    setSelectedTime('');
    setAppointmentType('Checkup');
    setSelectedDentist('');
    setNotes('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Book an Appointment</DialogTitle>
          <DialogDescription>
            Choose your preferred date, time, and type of appointment
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 col-span-2">
              <Label>Appointment Type</Label>
              <Select value={appointmentType} onValueChange={setAppointmentType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Checkup">Regular Checkup</SelectItem>
                  <SelectItem value="Cleaning">Teeth Cleaning</SelectItem>
                  <SelectItem value="Filling">Filling</SelectItem>
                  <SelectItem value="Root Canal">Root Canal</SelectItem>
                  <SelectItem value="Extraction">Tooth Extraction</SelectItem>
                  <SelectItem value="Consultation">Consultation</SelectItem>
                  <SelectItem value="Emergency">Emergency</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 col-span-2">
              <Label>Select Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !selectedDate && 'text-gray-500'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => {
                      const today = new Date();
                      today.setHours(0, 0, 0, 0);
                      return date < today || date.getDay() === 0; // Disable past dates and Sundays
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Preferred Time</Label>
              <Select value={selectedTime} onValueChange={setSelectedTime} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  {availableTimes.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Preferred Dentist</Label>
              <Select value={selectedDentist} onValueChange={setSelectedDentist} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select dentist" />
                </SelectTrigger>
                <SelectContent>
                  {dentistOptions.map((dentist) => (
                    <SelectItem key={dentist.value} value={dentist.value}>
                      <div className="flex flex-col">
                        <span>{dentist.value}</span>
                        <span className="text-xs text-gray-500">{dentist.specialty}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 col-span-2">
              <Label htmlFor="notes">Additional Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any special requests or concerns?"
                rows={3}
              />
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-md">
            <h4 className="font-medium mb-2">Appointment Summary</h4>
            <div className="text-sm space-y-1 text-gray-700">
              <p><strong>Patient:</strong> {patient.name}</p>
              <p><strong>Type:</strong> {appointmentType}</p>
              {selectedDate && <p><strong>Date:</strong> {format(selectedDate, 'MMMM dd, yyyy')}</p>}
              {selectedTime && <p><strong>Time:</strong> {selectedTime}</p>}
              {selectedDentist && <p><strong>Dentist:</strong> {selectedDentist}</p>}
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!selectedDate || !selectedTime || !selectedDentist}
            >
              Confirm Booking
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
