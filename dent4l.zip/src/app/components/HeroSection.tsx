import { Button } from './ui/button';
import { Calendar, Award, Heart, Shield } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroSectionProps {
  onBookAppointment: () => void;
}

export function HeroSection({ onBookAppointment }: HeroSectionProps) {
  return (
    <section id="home" className="relative bg-gradient-to-br from-teal-50 to-blue-50 overflow-hidden">
      <div className="container mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-block">
              <span className="bg-teal-100 text-teal-800 px-4 py-2 rounded-full text-sm font-medium">
                Welcome to Smile Dental Care
              </span>
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Your Smile is Our{' '}
              <span className="text-teal-600">Priority</span>
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Experience compassionate, comprehensive dental care for the whole family. 
              Our state-of-the-art facility and expert team are dedicated to your oral health.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={onBookAppointment}
                size="lg"
                className="bg-teal-600 hover:bg-teal-700 text-lg px-8 py-6"
              >
                <Calendar className="mr-2 h-5 w-5" />
                Book Your Appointment
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-6 border-2 border-teal-600 text-teal-700 hover:bg-teal-50"
              >
                Learn More
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-6 pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center">
                  <Award className="h-6 w-6 text-teal-600" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">20+ Years</p>
                  <p className="text-sm text-gray-600">Experience</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Heart className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">5000+</p>
                  <p className="text-sm text-gray-600">Happy Patients</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Shield className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">100%</p>
                  <p className="text-sm text-gray-600">Safe Care</p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1762625570087-6d98fca29531?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjbGluaWMlMjBtb2Rlcm4lMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzI2MzIzMzh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Modern dental clinic interior"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-6 max-w-xs">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                  <svg className="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div>
                  <p className="font-bold text-gray-900 text-lg">Same-Day Appointments</p>
                  <p className="text-sm text-gray-600">Available for emergencies</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
