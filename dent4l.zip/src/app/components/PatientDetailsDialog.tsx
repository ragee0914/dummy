import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Patient } from '../types';
import { format } from 'date-fns';
import { Mail, Phone, Calendar, CreditCard, FileText } from 'lucide-react';

interface PatientDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  patient: Patient | null;
}

export function PatientDetailsDialog({ open, onOpenChange, patient }: PatientDetailsDialogProps) {
  if (!patient) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Patient Details</DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold">{patient.name}</h3>
            <Badge
              variant="secondary"
              className={
                patient.status === 'active'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }
            >
              {patient.status}
            </Badge>
          </div>

          <Separator />

          <div className="grid gap-4">
            <div className="flex items-start gap-3">
              <Mail className="h-5 w-5 text-gray-500 mt-0.5" />
              <div>
                <Label className="text-gray-500">Email</Label>
                <p>{patient.email}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Phone className="h-5 w-5 text-gray-500 mt-0.5" />
              <div>
                <Label className="text-gray-500">Phone</Label>
                <p>{patient.phone}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Calendar className="h-5 w-5 text-gray-500 mt-0.5" />
              <div>
                <Label className="text-gray-500">Date of Birth</Label>
                <p>{format(new Date(patient.dateOfBirth), 'MMMM dd, yyyy')}</p>
              </div>
            </div>

            {patient.insuranceProvider && (
              <div className="flex items-start gap-3">
                <CreditCard className="h-5 w-5 text-gray-500 mt-0.5" />
                <div>
                  <Label className="text-gray-500">Insurance Provider</Label>
                  <p>{patient.insuranceProvider}</p>
                </div>
              </div>
            )}
          </div>

          <Separator />

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-500">Last Visit</Label>
              <p>
                {patient.lastVisit
                  ? format(new Date(patient.lastVisit), 'MMM dd, yyyy')
                  : 'No visits yet'}
              </p>
            </div>
            <div>
              <Label className="text-gray-500">Next Appointment</Label>
              <p>
                {patient.nextAppointment
                  ? format(new Date(patient.nextAppointment), 'MMM dd, yyyy')
                  : 'None scheduled'}
              </p>
            </div>
          </div>

          {patient.notes && (
            <>
              <Separator />
              <div className="flex items-start gap-3">
                <FileText className="h-5 w-5 text-gray-500 mt-0.5" />
                <div className="flex-1">
                  <Label className="text-gray-500">Notes</Label>
                  <p className="text-sm mt-1">{patient.notes}</p>
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
