import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';

const teamMembers = [
  {
    name: 'Dr. Sarah Smith',
    role: 'General Dentist',
    specialty: 'DDS, General & Cosmetic Dentistry',
    description: 'With over 15 years of experience, Dr. Smith is passionate about creating beautiful, healthy smiles.',
    image: 'https://images.unsplash.com/photo-1758205307916-4d302e3819f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjB0ZWFtJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3MjcxMTUxMXww&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    name: 'Dr. Michael Johnson',
    role: 'Orthodontist',
    specialty: 'DMD, Orthodontics Specialist',
    description: 'Dr. Johnson specializes in creating perfect smiles through advanced orthodontic techniques.',
    image: 'https://images.unsplash.com/photo-1758205307912-5896ff0c65ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50aXN0JTIwZXhhbWluaW5nJTIwcGF0aWVudHxlbnwxfHx8fDE3NzI2NDkyNTl8MA&ixlib=rb-4.1.0&q=80&w=1080'
  },
  {
    name: 'Dr. Emily Lee',
    role: 'Endodontist',
    specialty: 'DDS, Root Canal Specialist',
    description: 'Expert in root canal therapy and saving damaged teeth with precision and care.',
    image: 'https://images.unsplash.com/photo-1642844819197-5f5f21b89ff8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHBhdGllbnQlMjBkZW50YWwlMjBvZmZpY2V8ZW58MXx8fHwxNzcyNjgzNDU4fDA&ixlib=rb-4.1.0&q=80&w=1080'
  }
];

export function TeamSection() {
  return (
    <section id="team" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-teal-600 font-semibold text-sm uppercase tracking-wider">
            Our Team
          </span>
          <h2 className="text-4xl font-bold text-gray-900 mt-2 mb-4">
            Meet Our Expert Dentists
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Our experienced team of dental professionals is dedicated to providing you 
            with the highest quality care in a comfortable environment.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member) => (
            <Card key={member.name} className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-80 overflow-hidden">
                <ImageWithFallback
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="text-2xl font-bold mb-1">{member.name}</h3>
                  <p className="text-teal-200 font-medium">{member.role}</p>
                </div>
              </div>
              <CardContent className="p-6">
                <p className="text-sm font-semibold text-teal-600 mb-2">{member.specialty}</p>
                <p className="text-gray-600">{member.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-white rounded-3xl shadow-xl p-12">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-teal-600 mb-2">20+</div>
              <p className="text-gray-600">Years Experience</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-teal-600 mb-2">5000+</div>
              <p className="text-gray-600">Happy Patients</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-teal-600 mb-2">15+</div>
              <p className="text-gray-600">Expert Staff</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-teal-600 mb-2">98%</div>
              <p className="text-gray-600">Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
