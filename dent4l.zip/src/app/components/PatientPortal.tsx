import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Calendar, Clock, MapPin, Phone, Mail, User, Plus, X } from 'lucide-react';
import { Patient, Appointment } from '../types';
import { format } from 'date-fns';
import { AppointmentBookingDialog } from './AppointmentBookingDialog';
import { toast } from 'sonner';

interface PatientPortalProps {
  patient: Patient;
  appointments: Appointment[];
  onBookAppointment: (appointment: Partial<Appointment>) => void;
  onCancelAppointment: (id: string) => void;
}

export function PatientPortal({
  patient,
  appointments,
  onBookAppointment,
  onCancelAppointment
}: PatientPortalProps) {
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const upcomingAppointments = useMemo(() => {
    return appointments
      .filter((apt) => apt.date >= today && apt.status !== 'cancelled' && apt.status !== 'completed')
      .sort((a, b) => {
        const dateCompare = a.date.localeCompare(b.date);
        if (dateCompare !== 0) return dateCompare;
        return a.time.localeCompare(b.time);
      });
  }, [appointments, today]);

  const pastAppointments = useMemo(() => {
    return appointments
      .filter((apt) => apt.date < today || apt.status === 'completed')
      .sort((a, b) => {
        const dateCompare = b.date.localeCompare(a.date);
        if (dateCompare !== 0) return dateCompare;
        return b.time.localeCompare(a.time);
      });
  }, [appointments, today]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCancelAppointment = (id: string) => {
    if (window.confirm('Are you sure you want to cancel this appointment?')) {
      onCancelAppointment(id);
      toast.success('Appointment cancelled successfully');
    }
  };

  const initials = patient.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="bg-white border-b">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarFallback className="bg-blue-600 text-white text-xl">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-semibold">Welcome, {patient.name.split(' ')[0]}!</h1>
                <p className="text-sm text-gray-600">Manage your dental appointments</p>
              </div>
            </div>
            <Button onClick={() => setBookingDialogOpen(true)} size="lg">
              <Plus className="mr-2 h-5 w-5" />
              Book Appointment
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Tabs defaultValue="upcoming" className="space-y-4">
              <TabsList>
                <TabsTrigger value="upcoming">
                  Upcoming Appointments ({upcomingAppointments.length})
                </TabsTrigger>
                <TabsTrigger value="history">
                  History ({pastAppointments.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming" className="space-y-4">
                {upcomingAppointments.length === 0 ? (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                      <p className="text-gray-600 mb-4">No upcoming appointments</p>
                      <Button onClick={() => setBookingDialogOpen(true)}>
                        Book Your First Appointment
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  upcomingAppointments.map((appointment) => (
                    <Card key={appointment.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center gap-2">
                              <h3 className="text-lg font-semibold">{appointment.type}</h3>
                              <Badge className={getStatusColor(appointment.status)} variant="secondary">
                                {appointment.status}
                              </Badge>
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center gap-2 text-gray-600">
                                <Calendar className="h-4 w-4" />
                                <span>{format(new Date(appointment.date), 'EEEE, MMMM dd, yyyy')}</span>
                              </div>
                              <div className="flex items-center gap-2 text-gray-600">
                                <Clock className="h-4 w-4" />
                                <span>{appointment.time}</span>
                              </div>
                              <div className="flex items-center gap-2 text-gray-600">
                                <User className="h-4 w-4" />
                                <span>{appointment.dentist}</span>
                              </div>
                              {appointment.notes && (
                                <div className="mt-2 p-3 bg-blue-50 rounded-md text-sm text-gray-700">
                                  <strong>Notes:</strong> {appointment.notes}
                                </div>
                              )}
                            </div>
                          </div>
                          {appointment.status !== 'completed' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCancelAppointment(appointment.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <X className="mr-1 h-4 w-4" />
                              Cancel
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                {pastAppointments.length === 0 ? (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <Clock className="h-12 w-12 text-gray-400 mb-4" />
                      <p className="text-gray-600">No past appointments</p>
                    </CardContent>
                  </Card>
                ) : (
                  pastAppointments.map((appointment) => (
                    <Card key={appointment.id} className="opacity-75">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{appointment.type}</h3>
                              <Badge className={getStatusColor(appointment.status)} variant="secondary">
                                {appointment.status}
                              </Badge>
                            </div>
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center gap-2 text-gray-600">
                                <Calendar className="h-4 w-4" />
                                <span>{format(new Date(appointment.date), 'MMMM dd, yyyy')}</span>
                              </div>
                              <div className="flex items-center gap-2 text-gray-600">
                                <User className="h-4 w-4" />
                                <span>{appointment.dentist}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Mail className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p>{patient.email}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Phone className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Phone</p>
                    <p>{patient.phone}</p>
                  </div>
                </div>
                {patient.insuranceProvider && (
                  <div className="flex items-start gap-3">
                    <User className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div>
                      <p className="text-sm text-gray-500">Insurance</p>
                      <p>{patient.insuranceProvider}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Office Location</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Smile Dental Care</p>
                    <p className="text-sm text-gray-600">123 Main Street</p>
                    <p className="text-sm text-gray-600">Suite 200</p>
                    <p className="text-sm text-gray-600">New York, NY 10001</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Phone className="h-5 w-5 text-gray-500 mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Office Phone</p>
                    <p>(555) 123-4567</p>
                  </div>
                </div>
                <div className="pt-2 border-t text-sm text-gray-600">
                  <p className="font-medium mb-1">Office Hours</p>
                  <p>Mon-Fri: 8:00 AM - 6:00 PM</p>
                  <p>Sat: 9:00 AM - 2:00 PM</p>
                  <p>Sun: Closed</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <AppointmentBookingDialog
        open={bookingDialogOpen}
        onOpenChange={setBookingDialogOpen}
        patient={patient}
        onBook={onBookAppointment}
      />
    </div>
  );
}
