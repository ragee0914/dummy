export interface Patient {
  id: string;
  name: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  lastVisit: string;
  nextAppointment?: string;
  insuranceProvider?: string;
  status: 'active' | 'inactive';
  notes?: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  time: string;
  type: 'Cleaning' | 'Checkup' | 'Filling' | 'Root Canal' | 'Extraction' | 'Consultation' | 'Emergency';
  status: 'scheduled' | 'confirmed' | 'completed' | 'cancelled';
  dentist: string;
  notes?: string;
}
