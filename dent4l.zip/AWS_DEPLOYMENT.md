# AWS EC2 Deployment Guide

## Complete Step-by-Step Deployment to AWS

### Prerequisites
- AWS Account
- EC2 instance (Ubuntu 22.04 LTS)
- SSH key pair downloaded
- Basic command line knowledge

---

## Step 1: Launch EC2 Instance

1. **Go to AWS Console** → EC2 → Instances
2. **Click "Launch Instance"**
3. **Settings:**
   - AMI: Ubuntu 22.04 LTS
   - Type: t2.micro (Free tier eligible)
   - Storage: 20GB (default)
   - Security Group: Allow ports 22, 80, 443, 3000
4. **Review and Launch**
5. **Select or create key pair** and download it

---

## Step 2: Connect to EC2

### Windows (PuTTY)
1. Convert `.pem` to `.ppk` (use PuTTYgen)
2. Open PuTTY
3. Host: `ec2-user@your-instance-ip`
4. Auth: Select your `.ppk` file
5. Connect

### Mac/Linux
```bash
# Make key readable
chmod 400 your-key.pem

# Connect
ssh -i your-key.pem ubuntu@your-instance-ip
```

---

## Step 3: Update System

```bash
sudo apt-get update
sudo apt-get upgrade -y
```

---

## Step 4: Install Node.js

```bash
# Add Node.js repository
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# Install Node.js and npm
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

---

## Step 5: Install PM2 (Process Manager)

```bash
# Install PM2 globally
sudo npm install -g pm2

# Verify
pm2 --version
```

---

## Step 6: Upload Your Project

### Option A: Using Git (Recommended)

```bash
# Install Git
sudo apt-get install -y git

# Clone your repository
git clone https://your-repo-url.git ~/dental-crm
cd ~/dental-crm
```

### Option B: Using SCP (Windows/Mac/Linux)

```bash
# From your local machine
scp -i your-key.pem -r ./project-folder ubuntu@your-instance-ip:~/dental-crm
```

---

## Step 7: Install Dependencies

```bash
cd ~/dental-crm
npm install
```

---

## Step 8: Test the Application

```bash
# Run temporarily to test
npm start

# Press Ctrl+C to stop
```

Visit `http://your-instance-ip:3000/home` to verify

---

## Step 9: Setup PM2 for Production

```bash
# Start with PM2
pm2 start server.js --name "dental-crm"

# Configure to restart on reboot
pm2 startup
pm2 save

# Verify it's running
pm2 list
pm2 logs dental-crm
```

---

## Step 10: Setup Nginx Reverse Proxy

```bash
# Install Nginx
sudo apt-get install -y nginx

# Create config file
sudo nano /etc/nginx/sites-available/dental-crm
```

**Paste this configuration:**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Save with: `Ctrl+X` → `Y` → `Enter`

**Enable the site:**
```bash
# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Enable your site
sudo ln -s /etc/nginx/sites-available/dental-crm /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

---

## Step 11: Setup SSL (HTTPS) with Let's Encrypt

```bash
# Install Certbot
sudo apt-get install -y certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot certonly --manual --preferred-challenges=dns -d your-domain.com

# Follow the prompts to validate your domain

# Update Nginx config
sudo nano /etc/nginx/sites-available/dental-crm
```

**Update the configuration:**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;  # Redirect to HTTPS
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    # SSL certificate paths
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

**Restart Nginx:**
```bash
sudo systemctl restart nginx
```

---

## Step 12: Setup Database Backups (Optional)

```bash
# Create backup directory
mkdir -p ~/backups

# Create backup script
nano ~/backup.sh
```

**Paste this script:**
```bash
#!/bin/bash
BACKUP_DIR="$HOME/backups"
APP_DATA="$HOME/dental-crm/data"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/data_backup_$TIMESTAMP.tar.gz" "$APP_DATA"

# Keep only last 30 days of backups
find "$BACKUP_DIR" -name "data_backup_*" -mtime +30 -delete
```

**Make it executable and schedule:**
```bash
chmod +x ~/backup.sh

# Edit crontab
crontab -e

# Add this line (backup daily at 2 AM):
0 2 * * * ~/backup.sh
```

---

## 🎉 Your Site is Live!

Access your application:
- **Website**: `https://your-domain.com`
- **CRM Admin**: `https://your-domain.com/admin`

---

## 📊 Monitor Your Application

```bash
# View logs
pm2 logs dental-crm

# View stats
pm2 monit

# List processes
pm2 list

# Restart application
pm2 restart dental-crm

# Stop application
pm2 stop dental-crm
```

---

## 🔒 Security Checklist

- ✅ Update firewall rules (port 22 SSH restricted)
- ✅ Enable automated backups
- ✅ Use HTTPS with SSL certificates
- ✅ Keep system packages updated: `sudo apt-get update && sudo apt-get upgrade -y`
- ✅ Setup auto-renewal for SSL: `sudo certbot renew --dry-run`
- ✅ Add authentication to CRM
- ✅ Monitor logs regularly

---

## 💻 Common Commands

```bash
# SSH into your instance
ssh -i your-key.pem ubuntu@your-instance-ip

# Navigate to app
cd ~/dental-crm

# View logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Restart services
sudo systemctl restart nginx
pm2 restart dental-crm

# Check disk space
df -h

# Check memory
free -m

# Reboot
sudo reboot
```

---

## 🔧 Troubleshooting

**502 Bad Gateway Error**
```bash
# Check if Node.js is running
pm2 list

# Restart it
pm2 restart dental-crm

# Check logs
pm2 logs dental-crm
```

**Port 3000 in use**
```bash
# Find process
lsof -i :3000

# Kill it
kill -9 <PID>
```

**Out of disk space**
```bash
# Check space
du -sh *

# Clean PM2 logs
pm2 flush

# Clean npm cache
npm cache clean --force
```

---

## 📈 Scaling Tips

As your clinic grows:

1. **Database Migration** - Switch from JSON to MongoDB/PostgreSQL
2. **CDN** - Use CloudFront for static files
3. **Load Balancer** - Use AWS Application Load Balancer
4. **Auto-scaling** - Setup auto-scaling groups
5. **RDS** - Use AWS RDS for managed database

---

## 📞 Support

For issues with AWS:
- Visit AWS Support Console
- Check CloudWatch logs
- Review security group rules
- Verify IAM permissions

For application issues:
- Check `pm2 logs`
- Check Nginx error logs
- Review browser console (F12)
- Check server.js for errors

---

**Happy Deploying!** 🚀

Created: March 6, 2026
