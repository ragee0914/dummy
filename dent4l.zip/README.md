# !@XxOr4lD0kt0r_123xX - Dental Clinic CRM System

A complete dental clinic management system with a patient-facing website and admin CRM dashboard.

## 📋 Features

### 🌐 Public Website (`!@XxOr4lD0kt0r_123xX.html`)
- Professional dental clinic landing page
- Service showcase (6 dental services)
- Team section with doctor profiles
- Appointment booking form
- Contact section with business information
- Fully responsive design

### 👨‍💼 Admin CRM Dashboard (`crm.html`)
- **Dashboard** - Overview with key metrics
- **Appointments** - Manage all patient appointments
- **Patients** - Patient database and history
- **Staff** - Team member management
- **Reports** - Business analytics and insights
- **Schedule** - Weekly staff availability

### 🔄 Backend API (`server.js`)
- Express.js server with RESTful API
- JSON-based data storage
- CRUD operations for appointments, patients, and staff
- Statistics and reporting endpoints

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher) - [Download](https://nodejs.org/)
- npm (comes with Node.js)

### Installation

1. **Extract files to your project directory**

2. **Install dependencies:**
```bash
npm install
```

3. **Start the server:**
```bash
npm start
```

The server will start on `http://localhost:3000`

### Access Points
- 🏠 **Website**: http://localhost:3000/home
- 📊 **CRM Dashboard**: http://localhost:3000/admin
- 📡 **API**: http://localhost:3000/api/...

## 📁 Project Structure

```
.
├── !@XxOr4lD0kt0r_123xX.html    # Patient-facing website
├── crm.html                      # Admin dashboard
├── server.js                     # Backend API server
├── package.json                  # Dependencies
├── data/                         # JSON data files
│   ├── appointments.json
│   ├── patients.json
│   └── staff.json
└── README.md                     # This file
```

## 🔌 API Endpoints

### Appointments
```
GET    /api/appointments           # Get all appointments
GET    /api/appointments/:id       # Get single appointment
POST   /api/appointments           # Create new appointment
PUT    /api/appointments/:id       # Update appointment
DELETE /api/appointments/:id       # Delete appointment
```

### Patients
```
GET    /api/patients              # Get all patients
GET    /api/patients/:id          # Get single patient
POST   /api/patients              # Create new patient
PUT    /api/patients/:id          # Update patient
DELETE /api/patients/:id          # Delete patient
```

### Staff & Reports
```
GET    /api/staff                 # Get all staff members
GET    /api/stats                 # Get dashboard statistics
GET    /api/reports/stats         # Get detailed analytics
GET    /api/reports/appointments  # Get appointments by date range
```

## 📝 JSON Data Format

### Appointment Object
```json
{
  "id": "unique-id",
  "name": "Patient Name",
  "email": "patient@example.com",
  "phone": "(555) 123-4567",
  "date": "2026-03-06",
  "time": "10:00 AM",
  "service": "Teeth Cleaning",
  "status": "pending|confirmed|cancelled",
  "notes": "Optional notes",
  "createdAt": "2026-03-05T10:00:00Z"
}
```

### Patient Object
```json
{
  "id": "unique-id",
  "name": "John Smith",
  "email": "john@example.com",
  "phone": "(555) 123-4567",
  "dateOfBirth": "1985-05-15",
  "address": "123 Main St, City, State",
  "insurance": "Insurance Provider",
  "visits": 5,
  "lastVisit": "2026-03-01",
  "notes": "Patient notes",
  "createdAt": "2025-01-10T10:00:00Z"
}
```

## 📱 Booking Form Usage

When patients book appointments on the website:
1. They fill out the booking form
2. Data is sent to the backend API
3. Appointment is stored in `data/appointments.json`
4. Status is automatically set to "pending"
5. Admin can confirm or manage it in the CRM

## 🖥️ Deploying to AWS EC2

### Step 1: Create EC2 Instance
1. Launch an Ubuntu 22.04 LTS instance
2. Open ports: 3000 (Node.js), 80 (HTTP), 443 (HTTPS)

### Step 2: Connect and Setup
```bash
# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 (process manager)
sudo npm install -g pm2
```

### Step 3: Deploy Files
```bash
# Create app directory
mkdir -p ~/dental-crm
cd ~/dental-crm

# Upload files via SCP or Git
git clone <your-repo-url> .
# OR
# Use SCP to copy files

# Install dependencies
npm install
```

### Step 4: Run with PM2
```bash
# Start the application
pm2 start server.js --name "dental-crm"

# Save PM2 config to restart on reboot
pm2 startup
pm2 save
```

### Step 5: Setup Nginx Reverse Proxy
```bash
# Install Nginx
sudo apt-get install -y nginx

# Create config file
sudo nano /etc/nginx/sites-available/dental-crm
```

Add this configuration:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/dental-crm /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 🛡️ Environment Configuration

Create a `.env` file for production settings:
```
PORT=3000
NODE_ENV=production
CORS_ORIGIN=https://your-domain.com
```

Update `server.js` to use these variables.

## 💾 Data Backup

Backup your JSON files regularly:
```bash
# Automated daily backup
0 2 * * * cp -r ~/dental-crm/data ~/backups/data-$(date +\%Y\%m\%d)
```

## 🔒 Security Best Practices

1. **Add authentication** - Require login for admin access
2. **Enable HTTPS** - Use Let's Encrypt SSL certificates
3. **Add rate limiting** - Prevent API abuse
4. **Validate input** - Sanitize all user inputs
5. **Database migration** - Consider MongoDB/PostgreSQL for production

## 📊 Monitor & Logs

View application logs:
```bash
pm2 logs dental-crm
```

Monitor resources:
```bash
pm2 monit
```

## 🐛 Troubleshooting

### Port 3000 already in use
```bash
# Find process using port 3000
lsof -i :3000
# Kill process
kill -9 <PID>
```

### Backend not responding
1. Check if server is running: `pm2 list`
2. Check logs: `pm2 logs`
3. Verify CORS settings in server.js
4. Check browser console for errors

### Data not persisting
1. Verify `data/` directory exists and has write permissions
2. Check JSON file format is valid
3. Review server logs for errors

## 📞 Support

For issues or questions:
1. Check the API documentation above
2. Review the sample JSON data files
3. Check server logs: `pm2 logs`
4. Verify environment variables

## 📄 License

This project is private and confidential.

## 🔄 Next Steps

1. **Add authentication** - Secure admin login
2. **Database migration** - Move from JSON to MongoDB/PostgreSQL
3. **Email notifications** - Send appointment confirmations
4. **Payment integration** - Accept online payments
5. **SMS reminders** - Send appointment reminders via SMS
6. **Mobile app** - React Native or Flutter app
7. **Video consultations** - Integrate video calling

---

**Created**: March 6, 2026
**System**: !@XxOr4lD0kt0r_123xX Dental Clinic CRM
**Version**: 1.0.0
