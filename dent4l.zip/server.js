import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

// Data files
const appointmentsFile = join(__dirname, 'data', 'appointments.json');
const patientsFile = join(__dirname, 'data', 'patients.json');
const staffFile = join(__dirname, 'data', 'staff.json');

// Ensure data directory exists
const dataDir = join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Helper functions
function readJsonFile(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      return [];
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading ${filePath}:`, error);
    return [];
  }
}

function writeJsonFile(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error(`Error writing to ${filePath}:`, error);
  }
}

// ============ APPOINTMENTS ============

// Get all appointments
app.get('/api/appointments', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  res.json(appointments);
});

// Get appointment by ID
app.get('/api/appointments/:id', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  const appointment = appointments.find(a => a.id === req.params.id);
  if (appointment) {
    res.json(appointment);
  } else {
    res.status(404).json({ error: 'Appointment not found' });
  }
});

// Create new appointment
app.post('/api/appointments', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  const newAppointment = {
    id: uuidv4(),
    ...req.body,
    createdAt: new Date().toISOString()
  };
  appointments.push(newAppointment);
  writeJsonFile(appointmentsFile, appointments);
  res.status(201).json(newAppointment);
});

// Update appointment
app.put('/api/appointments/:id', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  const index = appointments.findIndex(a => a.id === req.params.id);
  if (index !== -1) {
    appointments[index] = { ...appointments[index], ...req.body };
    writeJsonFile(appointmentsFile, appointments);
    res.json(appointments[index]);
  } else {
    res.status(404).json({ error: 'Appointment not found' });
  }
});

// Delete appointment
app.delete('/api/appointments/:id', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  const index = appointments.findIndex(a => a.id === req.params.id);
  if (index !== -1) {
    const deleted = appointments.splice(index, 1);
    writeJsonFile(appointmentsFile, appointments);
    res.json(deleted[0]);
  } else {
    res.status(404).json({ error: 'Appointment not found' });
  }
});

// ============ PATIENTS ============

// Get all patients
app.get('/api/patients', (req, res) => {
  const patients = readJsonFile(patientsFile);
  res.json(patients);
});

// Get patient by ID
app.get('/api/patients/:id', (req, res) => {
  const patients = readJsonFile(patientsFile);
  const patient = patients.find(p => p.id === req.params.id);
  if (patient) {
    res.json(patient);
  } else {
    res.status(404).json({ error: 'Patient not found' });
  }
});

// Create new patient
app.post('/api/patients', (req, res) => {
  const patients = readJsonFile(patientsFile);
  const newPatient = {
    id: uuidv4(),
    ...req.body,
    visits: 0,
    createdAt: new Date().toISOString()
  };
  patients.push(newPatient);
  writeJsonFile(patientsFile, patients);
  res.status(201).json(newPatient);
});

// Update patient
app.put('/api/patients/:id', (req, res) => {
  const patients = readJsonFile(patientsFile);
  const index = patients.findIndex(p => p.id === req.params.id);
  if (index !== -1) {
    patients[index] = { ...patients[index], ...req.body };
    writeJsonFile(patientsFile, patients);
    res.json(patients[index]);
  } else {
    res.status(404).json({ error: 'Patient not found' });
  }
});

// Delete patient
app.delete('/api/patients/:id', (req, res) => {
  const patients = readJsonFile(patientsFile);
  const index = patients.findIndex(p => p.id === req.params.id);
  if (index !== -1) {
    const deleted = patients.splice(index, 1);
    writeJsonFile(patientsFile, patients);
    res.json(deleted[0]);
  } else {
    res.status(404).json({ error: 'Patient not found' });
  }
});

// ============ STAFF ============

// Get all staff
app.get('/api/staff', (req, res) => {
  const staff = readJsonFile(staffFile);
  res.json(staff);
});

// ============ STATISTICS ============

// Get dashboard statistics
app.get('/api/stats', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  const patients = readJsonFile(patientsFile);
  
  const today = new Date().toISOString().split('T')[0];
  const todayAppointments = appointments.filter(a => a.date === today);
  const pendingAppointments = appointments.filter(a => a.status === 'pending');

  res.json({
    totalAppointments: appointments.length,
    todayAppointments: todayAppointments.length,
    totalPatients: patients.length,
    pendingConfirmations: pendingAppointments.length
  });
});

// ============ REPORTS ============

// Get appointments by date range
app.get('/api/reports/appointments', (req, res) => {
  const { startDate, endDate } = req.query;
  const appointments = readJsonFile(appointmentsFile);
  
  let filtered = appointments;
  if (startDate && endDate) {
    filtered = appointments.filter(a => 
      a.date >= startDate && a.date <= endDate
    );
  }

  res.json(filtered);
});

// Get appointment statistics
app.get('/api/reports/stats', (req, res) => {
  const appointments = readJsonFile(appointmentsFile);
  
  const stats = {
    totalAppointments: appointments.length,
    confirmed: appointments.filter(a => a.status === 'confirmed').length,
    pending: appointments.filter(a => a.status === 'pending').length,
    cancelled: appointments.filter(a => a.status === 'cancelled').length,
    byService: {}
  };

  appointments.forEach(apt => {
    if (!stats.byService[apt.service]) {
      stats.byService[apt.service] = 0;
    }
    stats.byService[apt.service]++;
  });

  res.json(stats);
});

// Serve HTML files
app.get('/admin', (req, res) => {
  res.sendFile(join(__dirname, 'crm.html'));
});

app.get('/home', (req, res) => {
  res.sendFile(join(__dirname, '!@XxOr4lD0kt0r_123xX.html'));
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════╗
║   !@XxOr4lD0kt0r_123xX - Dental CRM System    ║
╚════════════════════════════════════════════════╝

✓ Server running on http://localhost:${PORT}

📍 Access Points:
  - Website:  http://localhost:${PORT}/home
  - CRM:      http://localhost:${PORT}/admin
  - API:      http://localhost:${PORT}/api/...

📊 API Endpoints:
  GET/POST   /api/appointments
  GET/PUT    /api/appointments/:id
  DELETE     /api/appointments/:id
  
  GET/POST   /api/patients
  GET/PUT    /api/patients/:id
  DELETE     /api/patients/:id
  
  GET        /api/staff
  GET        /api/stats
  GET        /api/reports/appointments
  GET        /api/reports/stats

Press Ctrl+C to stop the server
  `);
});
