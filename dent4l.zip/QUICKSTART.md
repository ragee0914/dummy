# Quick Start Guide - !@XxOr4lD0kt0r_123xX Dental CRM

## 🚀 Get Running in 2 Minutes

### For Windows Users (PowerShell)

1. **Open PowerShell in your project folder**

2. **Install dependencies:**
```powershell
npm install
```

3. **Start the server:**
```powershell
npm start
```

4. **Open in your browser:**
   - Website: http://localhost:3000/home
   - CRM Admin: http://localhost:3000/admin

### For Mac/Linux Users

1. **Open Terminal in your project folder**

2. **Install dependencies:**
```bash
npm install
```

3. **Start the server:**
```bash
npm start
```

4. **Open in your browser:**
   - Website: http://localhost:3000/home
   - CRM Admin: http://localhost:3000/admin

## ✅ What Should Happen

When the server starts, you should see:
```
╔════════════════════════════════════════════════╗
║   !@XxOr4lD0kt0r_123xX - Dental CRM System    ║
╚════════════════════════════════════════════════╝

✓ Server running on http://localhost:3000
...
```

## 📝 Test the System

### 1. Book an Appointment
- Go to http://localhost:3000/home
- Click "Book Appointment" button
- Fill out the form and submit
- Check http://localhost:3000/admin → Appointments tab

### 2. View Dashboard
- Go to http://localhost:3000/admin
- See real-time statistics
- View upcoming appointments

### 3. Check Reports
- Click "Reports" in the CRM
- View appointment analytics
- Check breakdown by service

## 🛑 Stop the Server

Press `Ctrl + C` in the terminal

## ⚙️ Troubleshooting

**"Cannot find module 'express'"**
- Run: `npm install`

**"Port 3000 already in use"**
- Stop other applications using port 3000
- Or change the port in `server.js` (change `const PORT = 3000;`)

**"Data files not found"**
- The `data/` folder should be created automatically
- Check permissions on the folder

## 📁 File Locations

- Website HTML: `!@XxOr4lD0kt0r_123xX.html`
- CRM Dashboard: `crm.html`
- Backend Server: `server.js`
- Sample Data: `data/` folder

## 📊 Default Test Data

The system comes with sample data:
- ✔️ 5 sample appointments
- ✔️ 5 sample patients  
- ✔️ 5 sample staff members

(Data is stored in `data/*.json` files)

## 🔗 API Endpoints Reference

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/appointments` | Get all appointments |
| POST | `/api/appointments` | Create new appointment |
| GET | `/api/patients` | Get all patients |
| GET | `/api/staff` | Get all staff |
| GET | `/api/stats` | Get dashboard stats |

## 🎯 Next Steps

1. Modify branding/colors as needed
2. Add more sample data
3. Test all features
4. Deploy to AWS EC2 (see README.md)
5. Add authentication
6. Integrate with email service

## 📞 Need Help?

Check these files:
- `README.md` - Full documentation
- `server.js` - API implementation
- Browser Developer Tools (F12) - JavaScript errors

---

**Enjoy your Dental CRM System!** 🦷✨
